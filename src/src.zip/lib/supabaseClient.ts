// src/lib/supabaseClient.ts
"use client";

import { createClient } from "@supabase/supabase-js";

export const supabaseUrl = "https://pszericxiukfxiwexxrs.supabase.co";
export const supabaseAnonKey = "sb_publishable_uLsFp0KPKYCptBkVodHdyQ_hpF3x6hf";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
