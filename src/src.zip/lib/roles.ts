export const ROLES = {
  ADMIN: "admin",
  PROFESIONAL: "profesional",
  RECEPCION: "recepcion",
  PACIENTE: "paciente",
};
