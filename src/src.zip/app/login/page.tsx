"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import "./login.css";

export default function LoginPage() {
  const router = useRouter();

  const [usuario, setUsuario] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  // Usuarios predefinidos
  const usuariosDB = [
    { user: "admin", pass: "admin123", rol: "admin" },
    { user: "medico", pass: "medico123", rol: "medico" },
    { user: "secre", pass: "secre123", rol: "secretaria" },
  ];

  const login = () => {
    const encontrado = usuariosDB.find(
      (u) =>
        u.user.toLowerCase() === usuario.trim().toLowerCase() &&
        u.pass === password.trim()
    );

    if (!encontrado) {
      setError("Usuario o contraseña incorrectos");
      return;
    }

    localStorage.setItem("rol", encontrado.rol);

    router.push("/dashboard");
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <i className="bi bi-hospital login-icon"></i>
        <h2 className="login-title">Ingreso al sistema</h2>

        <input
          type="text"
          placeholder="Usuario"
          className="login-input"
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
        />

        <input
          type="password"
          placeholder="Contraseña"
          className="login-input"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {error && <p className="login-error">{error}</p>}

        <button className="login-btn" onClick={login}>
          Ingresar
        </button>
      </div>
    </div>
  );
}
